# KitBench

A single-page storefront for student project kits in **robotics**, **embedded systems** and **VLSI / FPGA**, with three levels per area (mini, average, final year).

The whole front end is one file: `index.html`. No build step.

## Features

- 450+ project kits with search, sorting, level filters and saved projects
- Cart, checkout with Razorpay (online) or cash on delivery
- Student sign-up with email verification (via backend)
- Reviews, project requests, equipment purchase orders (stored in the browser)
- Light and dark theme, responsive layout, animated 3D robot intro (desktop only)

## Run locally

Open `index.html` in a browser, or serve the folder:

```bash
python3 -m http.server 8000
# then visit http://localhost:8000
```

## Deploy on GitHub Pages

1. Push this repo to GitHub.
2. Go to **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
4. Your site appears at `https://<your-username>.github.io/<repo-name>/`.

## Configuration

Edit `KB_SETTINGS` near the checkout code in `index.html`:

| Key | Meaning |
| --- | --- |
| `apiBase` | URL of your backend (for example on Render) |
| `razorpayKeyId` | Razorpay **Key ID** only (`rzp_test_...` or `rzp_live_...`) |
| `couponsLive` | Leave `false` until the server validates coupons |

**Never put your Razorpay secret key in this repository.** Keep it in the backend's environment variables.

## Backend endpoints expected

- `POST /api/create-order` and `POST /api/verify-payment`
- `POST /api/orders/cod`
- `POST /api/project-requests`
- `POST /api/auth/register`, `/api/auth/verify-email`, `/api/auth/login`

## Notes

- Orders, reviews, saved items and the admin preview are stored in the browser (`localStorage`). They are a demo, not a secure admin system.
- Coupons are previewed only until `couponsLive` is turned on and the server recalculates totals itself.
